"""ChessQuiz API — main entry point."""

from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from backend.api import chess_router, positions_router, quiz_router, tags_router
from backend.database import Base, engine

# Create all tables on startup
Base.metadata.create_all(bind=engine)

app = FastAPI(title="ChessQuiz", version="0.1.0")

# CORS for local React dev server
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(positions_router, prefix="/api")
app.include_router(quiz_router, prefix="/api")
app.include_router(tags_router, prefix="/api")
app.include_router(chess_router, prefix="/api")

FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"


@app.get("/api/health")
def health_check():
    return {"status": "ok", "app": "ChessQuiz"}


@app.get("/")
def serve_frontend():
    return FileResponse(FRONTEND_DIR / "index.html")
